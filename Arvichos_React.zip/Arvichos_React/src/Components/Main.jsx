import './Main.css';


const Main = () => (
    <>
        <h1>Hola mundo</h1>
        <h2>Aprendiendo React</h2>
        <p><small>Help</small></p>
    </>
)


export default Main;
